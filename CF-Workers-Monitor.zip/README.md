# CF-Workers-Monitor

Cloudflare Workers & Pages usage monitor with auto-deploy.

## Deployment
Configure GitHub Secrets:
- CF_API_TOKEN
- CF_ACCOUNT_ID
- EDGE

Push to main to auto deploy.
